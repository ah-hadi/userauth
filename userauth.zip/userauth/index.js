var express = require("express");
var app = express();
var port = 4000;
const route = require("./routes/route.js");
const bodyParser = require("body-parser");

app.use(bodyParser.json());
app.use("/", route);
app.listen(port || 4000, function () {
  var datetime = new Date();
  var message = "Server running on port:-" + port + "Started at:-" + datetime;
  console.log(message);
});
