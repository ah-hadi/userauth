var jwt = require("jsonwebtoken");

function admin(req, res) {
  let email = req.body.email;
  let password = req.body.password;
  let valu = {
    email: email,
    password: password,
  };
  const token = jwt.sign(valu, "my super secret key", { expiresIn: "15m" });
  res.send(token);
}
function user(req, res) {
  const token = jwt.sign(
    { email: "user@gmail.com", password: "user123" },
    "my super secret key",
    { expiresIn: "15m" }
  );
  res.send(token);
}
function admindetails(req, res) {
  res.status(200).json({
    role: "Welcome Admin",
    email: "admin@gmail.com",
    password: "admin123",
    gender: "male",
  });
}
function userdetails(req, res) {
  res.status(200).json({
    role: "Welcome user",
    email: "user@gmail.com",
    password: "user123",
    gender: "male",
  });
}

module.exports = {
  user,
  admin,
  admindetails,
  userdetails,
};
