const { response } = require("express");
var jwt = require("jsonwebtoken");
//const jwt_decode = require("jwt-decode");

const data = {
  admindata: { email: "admin@gmail.com", password: "admin123" },
  userdata: { email: "user@gmail.com", password: "user123" },
};

const middleware = (req, res, next) => {
  let email = req.body.email;
  let password = req.body.password;
  console.log(password);
  if (data.admindata.email === email && data.admindata.password === password) {
    next();
  } else if (
    data.userdata.email === email &&
    data.userdata.password === password
  ) {
    next();
  } else {
    res.status(401).send("not found");
  }
};

function extractToken(req, res, next) {
  var token = req.headers.authorization.split(" ")[1];
  var vtoken = jwt.verify(token, "my super secret key");
  if (vtoken.email === "admin@gmail.com") {
    next();
  } else {
    res.status(401).send({ result: "please add valid token" });
  }
}

function userToken(req, res, next) {
  var token = req.headers.authorization.split(" ")[1];
  var vtoken = jwt.verify(token, "my super secret key");
  console.log(vtoken.email);
  if (vtoken.email === "user@gmail.com" || vtoken.email === "admin@gmail.com") {
    next();
  } else {
    res.status(401).send({ result: "please add valid token" });
  }
}
module.exports = {
  middleware,
  extractToken,
  userToken,
};
