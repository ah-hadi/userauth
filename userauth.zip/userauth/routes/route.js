var express = require("express");
var controller = require("../controller/controller");
const {
  middleware,
  extractToken,
  userToken,
} = require("../middleware/middleware");

var route = express.Router();

route.post("/authentication", middleware, controller.admin);
route.post("/admin", middleware, controller.user);
route.get("/authentication", extractToken, controller.admin);
route.get("/admindetail", extractToken, controller.admindetails);
route.get("/userdetail", userToken, controller.userdetails);

module.exports = route;
